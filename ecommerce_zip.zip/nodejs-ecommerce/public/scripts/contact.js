/*function sendMail() {
  let params = {
    name: document.getElementById("inOne").value,
    email: document.getElementById("inTwo").value,
    message: document.getElementById("mes").value,
  };

  const serviceID = "service_t1dza6u";
  const templateID = "template_x2hki2o";

  emailjs
    .send(serviceID, templateID, params)
    .then((res) => {
      document.getElementById("inOne").value = "";
      document.getElementById("inTwo").value = "";
      document.getElementById("mes").value = "";
      alert("Your message has been sent successfully");
    })
    .catch((err) => console.log(err));
}
*/
